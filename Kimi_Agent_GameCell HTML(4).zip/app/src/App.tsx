import { useEffect, useState, useRef } from 'react';
import { 
  Gamepad2, 
  MapPin, 
  Menu, 
  X, 
  Smartphone, 
  Battery, 
  Droplets, 
  Cpu, 
  Plug, 
  Volume2,
  Shield,
  Gem,
  Timer,
  HandCoins,
  Home,
  Truck,
  Star,
  Clock,
  MapPinned,
  Instagram,
  Facebook,
  MessageCircle,
  Navigation,
  Gift,
  User,
  Mail,
  CheckCircle,
  Copy,
  AlertCircle,
  Play,
  Video
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set());
  const sectionRefs = useRef<{ [key: string]: HTMLElement | null }>({});

  // Estados do sistema de vouchers
  const [voucherForm, setVoucherForm] = useState({ nome: '', sobrenome: '', email: '' });
  const [voucherGerado, setVoucherGerado] = useState<string | null>(null);
  const [vouchersRestantes, setVouchersRestantes] = useState(200);
  const [voucherError, setVoucherError] = useState('');
  const [voucherSuccess, setVoucherSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  // Carregar vouchers do localStorage e contar visitas
  useEffect(() => {
    const vouchersSalvos = localStorage.getItem('gamecell_vouchers');
    if (vouchersSalvos) {
      const vouchers = JSON.parse(vouchersSalvos);
      setVouchersRestantes(200 - vouchers.length);
    }

    // Contador de visitas - salva no localStorage para o admin ver
    const hoje = new Date().toDateString();
    const visitasData = localStorage.getItem('gamecell_visitas');
    let visitas = visitasData ? JSON.parse(visitasData) : { total: 0, porDia: {} };
    
    // Incrementar visita
    visitas.total += 1;
    visitas.porDia[hoje] = (visitas.porDia[hoje] || 0) + 1;
    
    localStorage.setItem('gamecell_visitas', JSON.stringify(visitas));
  }, []);

  // Função para gerar código único
  const gerarCodigoVoucher = () => {
    const prefixo = 'GC';
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefixo}-${timestamp}-${random}`;
  };

  // Função para gerar voucher
  const gerarVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    setVoucherError('');

    // Validações
    if (!voucherForm.nome.trim() || !voucherForm.sobrenome.trim() || !voucherForm.email.trim()) {
      setVoucherError('Preencha todos os campos obrigatórios.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(voucherForm.email)) {
      setVoucherError('Digite um email válido.');
      return;
    }

    // Verificar se email já tem voucher
    const vouchersSalvos = JSON.parse(localStorage.getItem('gamecell_vouchers') || '[]');
    const emailExistente = vouchersSalvos.find((v: any) => v.email === voucherForm.email);
    if (emailExistente) {
      setVoucherError('Este email já possui um voucher. Verifique seu email ou entre em contato.');
      return;
    }

    // Verificar limite
    if (vouchersSalvos.length >= 200) {
      setVoucherError('Todos os 200 vouchers foram esgotados! Acompanhe nossas redes para novas promoções.');
      return;
    }

    // Gerar novo voucher
    const novoVoucher = {
      codigo: gerarCodigoVoucher(),
      nome: voucherForm.nome,
      sobrenome: voucherForm.sobrenome,
      email: voucherForm.email,
      desconto: 20,
      data: new Date().toISOString(),
      usado: false
    };

    // Salvar
    vouchersSalvos.push(novoVoucher);
    localStorage.setItem('gamecell_vouchers', JSON.stringify(vouchersSalvos));

    // Atualizar estado
    setVoucherGerado(novoVoucher.codigo);
    setVouchersRestantes(200 - vouchersSalvos.length);
    setVoucherSuccess(true);
  };

  // Copiar código
  const copiarCodigo = () => {
    if (voucherGerado) {
      navigator.clipboard.writeText(voucherGerado);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections((prev) => new Set([...prev, entry.target.id]));
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    Object.values(sectionRefs.current).forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  const setRef = (id: string) => (el: HTMLElement | null) => {
    sectionRefs.current[id] = el;
  };

  const isVisible = (id: string) => visibleSections.has(id);

  const services = [
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: 'Troca de Tela',
      description: 'Telas quebradas, trincadas ou com touch defeituoso. Trabalhamos com telas de qualidade e garantia de instalação.',
      price: 'A partir de R$ 150'
    },
    {
      icon: <Battery className="w-8 h-8" />,
      title: 'Troca de Bateria',
      description: 'Bateria viciada, descarregando rápido ou inchada? Trocamos por baterias novas com durabilidade garantida.',
      price: 'A partir de R$ 80'
    },
    {
      icon: <Droplets className="w-8 h-8" />,
      title: 'Recuperação de Água',
      description: 'Celular molhou? Temos equipamento especializado para limpeza e recuperação de oxidação.',
      price: 'A partir de R$ 100'
    },
    {
      icon: <Cpu className="w-8 h-8" />,
      title: 'Reparo de Placa',
      description: 'Celular não liga, não carrega ou reiniciando? Diagnóstico completo e reparo de curto na placa.',
      price: 'Orçamento Grátis'
    },
    {
      icon: <Plug className="w-8 h-8" />,
      title: 'Conector de Carga',
      description: 'Dificuldade para carregar? Trocamos o conector USB/C com solda profissional.',
      price: 'A partir de R$ 60'
    },
    {
      icon: <Volume2 className="w-8 h-8" />,
      title: 'Áudio e Vibração',
      description: 'Alto-falante falhando, microfone ruim ou vibração parada? Consertamos todos os problemas de áudio.',
      price: 'A partir de R$ 50'
    }
  ];

  const features = [
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'Garantia de 30 Dias',
      description: 'Garantia da peça instalada contra defeitos de fabricação. NÃO COBRE: mau uso, quedas, contato com líquidos, oxidação, uso de carregador não original, atualizações não oficiais, root/desbloqueio, aperto excessivo na tela, exposição ao calor, abertura por terceiros ou qualquer dano físico.'
    },
    {
      icon: <Gem className="w-6 h-6" />,
      title: 'Peças de Qualidade',
      description: 'Trabalhamos apenas com peças testadas e aprovadas. Nada de paralelo ruim.'
    },
    {
      icon: <Timer className="w-6 h-6" />,
      title: 'Rapidez',
      description: 'Consertos simples no mesmo dia. Troca de tela em até 2 horas.'
    },
    {
      icon: <HandCoins className="w-6 h-6" />,
      title: 'Orçamento Grátis',
      description: 'Diagnóstico sem compromisso. Você decide se quer consertar ou não.'
    },
    {
      icon: <Home className="w-6 h-6" />,
      title: 'Atendimento Local',
      description: 'Estamos em Curuai. Atendimento personalizado e de confiança.'
    },
    {
      icon: <Truck className="w-6 h-6" />,
      title: 'Entrega Domiciliar',
      description: 'Levamos e buscamos seu celular em casa. Comodidade total.'
    }
  ];

  const steps = [
    { number: '1', title: 'Orçamento', description: 'Você traz ou envia fotos pelo WhatsApp' },
    { number: '2', title: 'Aprovação', description: 'Você aprova o valor e o serviço' },
    { number: '3', title: 'Reparo', description: 'Consertamos com cuidado e qualidade' },
    { number: '4', title: 'Entrega', description: 'Testamos tudo e entregamos funcionando' }
  ];

  const testimonials = [
    {
      text: 'Troquei a tela do meu iPhone e ficou perfeita! Atendimento super atencioso, preço justo e ainda ganhei película de brinde. Recomendo demais!',
      author: 'João Marcos',
      initials: 'JM',
      since: 'Cliente desde 2023',
      rating: 5
    },
    {
      text: 'Meu celular tinha caído na água e achei que tinha perdido. A GameCell recuperou tudo! Salvou minhas fotos e contatos. Serviço impecável.',
      author: 'Ana Silva',
      initials: 'AS',
      since: 'Cliente desde 2024',
      rating: 5
    },
    {
      text: 'Já levei 3 celulares diferentes para consertar aqui. Sempre honesto, não inventa problema onde não tem. Confiança total no trabalho!',
      author: 'Pedro Oliveira',
      initials: 'PO',
      since: 'Cliente desde 2022',
      rating: 4.5
    }
  ];

  const whatsappLink = 'https://wa.me/5593984201437?text=Olá!%20Vim%20pelo%20site%20e%20gostaria%20de%20um%20orçamento.';

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Scanline effect */}
      <div className="scanline" />

      {/* Header */}
      <header 
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-[rgba(10,10,10,0.98)] shadow-[0_2px_20px_rgba(57,255,20,0.1)]' 
            : 'bg-[rgba(10,10,10,0.95)]'
        }`}
        style={{ backdropFilter: 'blur(10px)', borderBottom: '1px solid #333' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex justify-between items-center py-4">
            <a href="#" className="flex items-center gap-2 text-2xl font-extrabold text-white no-underline">
              <Gamepad2 className="w-8 h-8 text-[#39ff14]" />
              Game<span className="text-[#39ff14]" style={{ textShadow: '0 0 10px #39ff14' }}>Cell</span>
            </a>

            {/* Desktop Navigation */}
            <ul className="hidden md:flex gap-8 list-none">
              {['promocao', 'servicos', 'diferenciais', 'como-funciona', 'depoimentos', 'videos', 'contato'].map((item) => (
                <li key={item}>
                  <a 
                    href={`#${item}`} 
                    className="nav-link relative text-[#888] font-medium transition-all duration-300 hover:text-[#39ff14] hover:[text-shadow:0_0_10px_#39ff14]"
                  >
                    {item === 'promocao' && <span className="text-[#39ff14]">Promoção</span>}
                    {item === 'servicos' && 'Serviços'}
                    {item === 'diferenciais' && 'Diferenciais'}
                    {item === 'como-funciona' && 'Como Funciona'}
                    {item === 'depoimentos' && 'Depoimentos'}
                    {item === 'videos' && 'Vídeos'}
                    {item === 'contato' && 'Contato'}
                  </a>
                </li>
              ))}
            </ul>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-[#39ff14] text-2xl"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </nav>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden bg-[#0a0a0a] border-t border-[#39ff14] py-4">
              <ul className="flex flex-col gap-4 list-none">
                {['promocao', 'servicos', 'diferenciais', 'como-funciona', 'depoimentos', 'videos', 'contato'].map((item) => (
                  <li key={item}>
                    <a 
                      href={`#${item}`} 
                      className="block text-[#888] font-medium hover:text-[#39ff14] py-2"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item === 'promocao' && 'Promoção'}
                      {item === 'servicos' && 'Serviços'}
                      {item === 'diferenciais' && 'Diferenciais'}
                      {item === 'como-funciona' && 'Como Funciona'}
                      {item === 'depoimentos' && 'Depoimentos'}
                      {item === 'videos' && 'Vídeos'}
                      {item === 'contato' && 'Contato'}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center text-center px-4 sm:px-6 lg:px-8 pt-24 pb-16 relative overflow-hidden">
        {/* Background gradient */}
        <div 
          className="absolute inset-0 animate-float"
          style={{
            background: 'radial-gradient(circle at center, rgba(57, 255, 20, 0.1) 0%, transparent 70%)'
          }}
        />
        
        {/* Pattern overlay */}
        <div className="absolute inset-0 hero-pattern opacity-30 animate-float" />

        <div className="relative z-10 max-w-3xl mx-auto animate-slide-in">
          <div 
            className="inline-flex items-center gap-2 px-6 py-2 bg-[rgba(57,255,20,0.1)] border border-[#39ff14] rounded-full text-[#39ff14] text-sm font-semibold uppercase tracking-wider mb-8 animate-glow"
          >
            <MapPin className="w-4 h-4" />
            Atendendo Curuai e Região
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 leading-tight">
            Assistência Técnica
            <span 
              className="block text-[#39ff14]"
              style={{ textShadow: '0 0 20px #39ff14, 0 0 40px #39ff14' }}
            >
              ESPECIALIZADA
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-[#888] mb-10 max-w-2xl mx-auto">
            Conserto de smartphones com peças de qualidade, garantia real e atendimento 
            que você pode confiar. Seu celular em boas mãos!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#39ff14] text-[#0a0a0a] font-semibold rounded-full transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(57,255,20,0.6),0_0_60px_rgba(57,255,20,0.3)]"
            >
              <MessageCircle className="w-5 h-5" />
              Pedir Orçamento Grátis
            </a>
            <a 
              href="#servicos"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-transparent text-[#39ff14] border-2 border-[#39ff14] font-semibold rounded-full transition-all duration-300 hover:bg-[#39ff14] hover:text-[#0a0a0a] hover:shadow-[0_0_20px_rgba(57,255,20,0.4)]"
            >
              Ver Serviços
            </a>
          </div>

          <div className="flex flex-wrap justify-center gap-8 sm:gap-12">
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-extrabold text-[#39ff14]" style={{ textShadow: '0 0 10px #39ff14' }}>
                500+
              </div>
              <div className="text-[#888] text-sm uppercase tracking-wider">Celulares Consertados</div>
            </div>
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-extrabold text-[#39ff14]" style={{ textShadow: '0 0 10px #39ff14' }}>
                3
              </div>
              <div className="text-[#888] text-sm uppercase tracking-wider">Anos de Experiência</div>
            </div>
            <div className="text-center">
              <div className="text-3xl sm:text-4xl font-extrabold text-[#39ff14]" style={{ textShadow: '0 0 10px #39ff14' }}>
                30 Dias
              </div>
              <div className="text-[#888] text-sm uppercase tracking-wider">Garantia da Peça</div>
            </div>
          </div>
        </div>
      </section>

      {/* Voucher Promocional Section */}
      <section 
        id="promocao" 
        className="py-20 bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a]"
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[rgba(57,255,20,0.1)] border border-[#39ff14] rounded-full text-[#39ff14] text-sm font-semibold uppercase tracking-wider mb-6">
              <Gift className="w-4 h-4" />
              Promoção Exclusiva
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Ganhe <span className="text-[#39ff14]">20% de Desconto</span>
            </h2>
            <p className="text-[#888] max-w-xl mx-auto">
              Cadastre-se agora e receba um voucher exclusivo com 20% de desconto no seu primeiro serviço!
            </p>
            <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-[rgba(255,0,0,0.1)] border border-red-500 rounded-full text-red-400 text-sm font-semibold">
              <AlertCircle className="w-4 h-4" />
              Apenas {vouchersRestantes} vouchers disponíveis
            </div>
          </div>

          {!voucherSuccess ? (
            <div className="bg-[#1a1a1a] border border-[#333] rounded-2xl p-8 shadow-[0_0_40px_rgba(57,255,20,0.1)]">
              <form onSubmit={gerarVoucher} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[#888] text-sm mb-2">Nome *</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888]" />
                      <input
                        type="text"
                        value={voucherForm.nome}
                        onChange={(e) => setVoucherForm({...voucherForm, nome: e.target.value})}
                        placeholder="Seu nome"
                        className="w-full bg-[#0a0a0a] border border-[#333] rounded-xl py-3 pl-12 pr-4 text-white placeholder-[#666] focus:border-[#39ff14] focus:outline-none focus:ring-2 focus:ring-[#39ff14]/20 transition-all"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[#888] text-sm mb-2">Sobrenome *</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888]" />
                      <input
                        type="text"
                        value={voucherForm.sobrenome}
                        onChange={(e) => setVoucherForm({...voucherForm, sobrenome: e.target.value})}
                        placeholder="Seu sobrenome"
                        className="w-full bg-[#0a0a0a] border border-[#333] rounded-xl py-3 pl-12 pr-4 text-white placeholder-[#666] focus:border-[#39ff14] focus:outline-none focus:ring-2 focus:ring-[#39ff14]/20 transition-all"
                        required
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-[#888] text-sm mb-2">Email *</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888]" />
                    <input
                      type="email"
                      value={voucherForm.email}
                      onChange={(e) => setVoucherForm({...voucherForm, email: e.target.value})}
                      placeholder="seu@email.com"
                      className="w-full bg-[#0a0a0a] border border-[#333] rounded-xl py-3 pl-12 pr-4 text-white placeholder-[#666] focus:border-[#39ff14] focus:outline-none focus:ring-2 focus:ring-[#39ff14]/20 transition-all"
                      required
                    />
                  </div>
                </div>

                {voucherError && (
                  <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    {voucherError}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={vouchersRestantes === 0}
                  className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
                    vouchersRestantes === 0
                      ? 'bg-[#333] text-[#666] cursor-not-allowed'
                      : 'bg-gradient-to-r from-[#39ff14] to-[#00ff9d] text-[#0a0a0a] hover:shadow-[0_0_30px_rgba(57,255,20,0.5)] hover:-translate-y-1'
                  }`}
                >
                  {vouchersRestantes === 0 ? 'Vouchers Esgotados' : 'Gerar Meu Voucher de 20% OFF'}
                </button>

                <p className="text-[#666] text-xs text-center">
                  * Voucher válido apenas para o primeiro serviço. Não cumulativo com outras promoções.
                </p>
              </form>
            </div>
          ) : (
            <div className="bg-[#1a1a1a] border-2 border-[#39ff14] rounded-2xl p-8 text-center shadow-[0_0_60px_rgba(57,255,20,0.2)]">
              <div className="w-20 h-20 bg-[rgba(57,255,20,0.2)] rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-[#39ff14]" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Parabéns, {voucherForm.nome}!</h3>
              <p className="text-[#888] mb-6">Seu voucher exclusivo foi gerado com sucesso!</p>
              
              <div className="bg-[#0a0a0a] border border-[#39ff14] rounded-xl p-6 mb-6">
                <p className="text-[#888] text-sm mb-2">Seu código de desconto:</p>
                <div className="flex items-center justify-center gap-4">
                  <code className="text-2xl sm:text-3xl font-mono font-bold text-[#39ff14]">
                    {voucherGerado}
                  </code>
                  <button
                    onClick={copiarCodigo}
                    className="p-2 bg-[#39ff14]/10 border border-[#39ff14] rounded-lg hover:bg-[#39ff14]/20 transition-all"
                    title="Copiar código"
                  >
                    {copied ? <CheckCircle className="w-5 h-5 text-[#39ff14]" /> : <Copy className="w-5 h-5 text-[#39ff14]" />}
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-[#888] text-sm">
                  <strong className="text-white">Como usar:</strong> Apresente este código no WhatsApp ou na loja ao solicitar seu orçamento.
                </p>
                <a
                  href={`https://wa.me/5593984201437?text=Olá!%20Tenho%20um%20voucher%20de%20desconto:%20${voucherGerado}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-8 py-3 bg-[#25d366] text-white font-bold rounded-full hover:bg-[#128c7e] transition-all"
                >
                  <MessageCircle className="w-5 h-5" />
                  Usar Voucher no WhatsApp
                </a>
              </div>

              <div className="mt-6 pt-6 border-t border-[#333]">
                <p className="text-[#666] text-xs">
                  Um email de confirmação foi enviado para {voucherForm.email}
                </p>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Services Section */}
      <section 
        id="servicos" 
        ref={setRef('servicos')}
        className="py-20 bg-[#1a1a1a]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Nossos <span className="text-[#39ff14]">Serviços</span>
            </h2>
            <p className="text-[#888] max-w-xl mx-auto">
              Especialistas em reparos de smartphones. Orçamento grátis e sem compromisso.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className={`service-card relative bg-[#0a0a0a] border border-[#333] rounded-2xl p-8 text-center transition-all duration-300 hover:border-[#39ff14] hover:-translate-y-2 hover:shadow-[0_10px_40px_rgba(57,255,20,0.1)] ${
                  isVisible('servicos') ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-20 h-20 bg-[rgba(57,255,20,0.1)] border-2 border-[#39ff14] rounded-full flex items-center justify-center mx-auto mb-6 text-[#39ff14] shadow-[0_0_20px_rgba(57,255,20,0.2)]">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold mb-4 text-white">{service.title}</h3>
                <p className="text-[#888] text-sm mb-6">{service.description}</p>
                <span className="inline-block px-4 py-2 bg-[rgba(57,255,20,0.1)] border border-[#39ff14] rounded-full text-[#39ff14] font-semibold text-sm">
                  {service.price}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section 
        id="diferenciais" 
        ref={setRef('diferenciais')}
        className="py-20 bg-[#0a0a0a]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Por que escolher a <span className="text-[#39ff14]">GameCell</span>?
            </h2>
            <p className="text-[#888] max-w-xl mx-auto">
              Diferenciais que fazem seu celular voltar a funcionar perfeitamente
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div 
                key={index}
                className={`flex items-start gap-4 p-6 bg-[#1a1a1a] rounded-xl border border-[#333] transition-all duration-300 hover:border-[#39ff14] hover:translate-x-1 ${
                  isVisible('diferenciais') ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-[#39ff14] min-w-[40px]" style={{ textShadow: '0 0 10px #39ff14' }}>
                  {feature.icon}
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-white">{feature.title}</h4>
                  <p className="text-[#888] text-sm">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section 
        id="como-funciona" 
        ref={setRef('como-funciona')}
        className="py-20 bg-[#1a1a1a]"
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Como <span className="text-[#39ff14]">Funciona</span>
            </h2>
            <p className="text-[#888] max-w-xl mx-auto">
              Processo simples e transparente do orçamento à entrega
            </p>
          </div>

          <div className="steps-connector relative flex flex-col md:flex-row justify-between items-center gap-8 md:gap-0">
            {steps.map((step, index) => (
              <div 
                key={index}
                className={`flex flex-col items-center relative z-10 ${
                  isVisible('como-funciona') ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="w-20 h-20 bg-[#0a0a0a] border-2 border-[#39ff14] rounded-full flex items-center justify-center text-2xl font-bold text-[#39ff14] shadow-[0_0_20px_rgba(57,255,20,0.3)]">
                  {step.number}
                </div>
                <div className="text-center mt-6 w-40">
                  <h4 className="text-white font-semibold mb-2">{step.title}</h4>
                  <p className="text-[#888] text-sm">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section 
        id="depoimentos" 
        ref={setRef('depoimentos')}
        className="py-20 bg-[#0a0a0a]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              O que dizem nossos <span className="text-[#39ff14]">Clientes</span>
            </h2>
            <p className="text-[#888] max-w-xl mx-auto">
              Experiências reais de quem já confiou na GameCell
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index}
                className={`testimonial-card relative bg-[#1a1a1a] border border-[#333] rounded-2xl p-8 ${
                  isVisible('depoimentos') ? 'animate-fade-in-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex gap-1 mb-4 text-[#39ff14]">
                  {[...Array(Math.floor(testimonial.rating))].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                  {testimonial.rating % 1 !== 0 && (
                    <Star className="w-5 h-5 fill-current opacity-50" />
                  )}
                </div>
                <p className="text-[#888] mb-6 italic">{testimonial.text}</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-[#39ff14] rounded-full flex items-center justify-center text-[#0a0a0a] font-bold">
                    {testimonial.initials}
                  </div>
                  <div>
                    <h5 className="text-white font-semibold">{testimonial.author}</h5>
                    <span className="text-[#888] text-sm">{testimonial.since}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Videos de Depoimentos Section */}
      <section 
        id="videos" 
        className="py-20 bg-[#0a0a0a]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[rgba(57,255,20,0.1)] border border-[#39ff14] rounded-full text-[#39ff14] text-sm font-semibold uppercase tracking-wider mb-6">
              <Video className="w-4 h-4" />
              Depoimentos em Vídeo
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Veja o que nossos <span className="text-[#39ff14]">clientes dizem</span>
            </h2>
            <p className="text-[#888] max-w-xl mx-auto">
              Histórias reais de quem confiou na GameCell para consertar seu celular.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Video 1 - Placeholder */}
            <div className="bg-[#1a1a1a] border border-[#333] rounded-2xl overflow-hidden hover:border-[#39ff14] transition-all duration-300">
              <div className="aspect-video bg-[#0a0a0a] flex items-center justify-center relative group cursor-pointer">
                <div className="w-16 h-16 bg-[#39ff14] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-[#0a0a0a] ml-1" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <p className="absolute bottom-4 left-4 text-white font-semibold">João Marcos</p>
              </div>
              <div className="p-4">
                <p className="text-[#888] text-sm">"Troquei a tela do meu iPhone e ficou perfeita! Super recomendo!"</p>
                <p className="text-[#39ff14] text-xs mt-2">📍 Curuai, PA</p>
              </div>
            </div>

            {/* Video 2 - Placeholder */}
            <div className="bg-[#1a1a1a] border border-[#333] rounded-2xl overflow-hidden hover:border-[#39ff14] transition-all duration-300">
              <div className="aspect-video bg-[#0a0a0a] flex items-center justify-center relative group cursor-pointer">
                <div className="w-16 h-16 bg-[#39ff14] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-[#0a0a0a] ml-1" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <p className="absolute bottom-4 left-4 text-white font-semibold">Ana Silva</p>
              </div>
              <div className="p-4">
                <p className="text-[#888] text-sm">"Meu celular caiu na água e a GameCell salvou tudo!"</p>
                <p className="text-[#39ff14] text-xs mt-2">📍 Curuai, PA</p>
              </div>
            </div>

            {/* Video 3 - Placeholder */}
            <div className="bg-[#1a1a1a] border border-[#333] rounded-2xl overflow-hidden hover:border-[#39ff14] transition-all duration-300">
              <div className="aspect-video bg-[#0a0a0a] flex items-center justify-center relative group cursor-pointer">
                <div className="w-16 h-16 bg-[#39ff14] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-[#0a0a0a] ml-1" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <p className="absolute bottom-4 left-4 text-white font-semibold">Pedro Oliveira</p>
              </div>
              <div className="p-4">
                <p className="text-[#888] text-sm">"Já levei 3 celulares aqui. Sempre honesto e com preço justo!"</p>
                <p className="text-[#39ff14] text-xs mt-2">📍 Curuai, PA</p>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center">
            <div className="bg-[#1a1a1a] border border-[#333] rounded-2xl p-8 max-w-2xl mx-auto">
              <Video className="w-12 h-12 text-[#39ff14] mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Quer deixar seu depoimento?</h3>
              <p className="text-[#888] mb-4">
                Grave um vídeo curto contando sua experiência com a GameCell e ganhe <span className="text-[#39ff14] font-bold">10% de desconto</span> no seu próximo serviço!
              </p>
              <a 
                href="https://wa.me/5593984201437?text=Olá!%20Quero%20deixar%20meu%20depoimento%20em%20vídeo!"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#39ff14] text-[#0a0a0a] font-bold rounded-full hover:shadow-[0_0_20px_rgba(57,255,20,0.4)] transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                Enviar Depoimento
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section 
        id="contato" 
        ref={setRef('contato')}
        className="py-20 bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a]"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl sm:text-4xl font-bold mb-6">
                Vamos <span className="text-[#39ff14]">Conversar</span>?
              </h3>
              <p className="text-[#888] mb-8">
                Entre em contato pelo WhatsApp ou venha nos visitar. 
                Atendimento rápido e sem burocracia!
              </p>

              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-[rgba(57,255,20,0.05)] rounded-xl border border-[#333]">
                  <MessageCircle className="w-6 h-6 text-[#39ff14]" />
                  <div>
                    <h4 className="text-white font-semibold">WhatsApp</h4>
                    <p className="text-[#888] text-sm">(93) 98420-1437 - Clique e fale direto</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-[rgba(57,255,20,0.05)] rounded-xl border border-[#333]">
                  <MapPinned className="w-6 h-6 text-[#39ff14]" />
                  <div>
                    <h4 className="text-white font-semibold">Localização</h4>
                    <p className="text-[#888] text-sm">Distrito de Curuai, Pará</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-[rgba(57,255,20,0.05)] rounded-xl border border-[#333]">
                  <Clock className="w-6 h-6 text-[#39ff14]" />
                  <div>
                    <h4 className="text-white font-semibold">Horário de Funcionamento</h4>
                    <p className="text-[#888] text-sm">Segunda a Sábado: 8h às 18h</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-[rgba(57,255,20,0.05)] rounded-xl border border-[#333]">
                  <Truck className="w-6 h-6 text-[#39ff14]" />
                  <div>
                    <h4 className="text-white font-semibold">Entrega Domiciliar</h4>
                    <p className="text-[#888] text-sm">Disponível em toda Curuai</p>
                  </div>
                </div>
              </div>

              <a 
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-8 px-8 py-4 bg-[#39ff14] text-[#0a0a0a] font-semibold rounded-full transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(57,255,20,0.6)]"
              >
                <MessageCircle className="w-5 h-5" />
                Chamar no WhatsApp
              </a>
            </div>

            <div className="bg-[#1a1a1a] border-2 border-[#39ff14] rounded-2xl overflow-hidden h-96 flex items-center justify-center shadow-[0_0_30px_rgba(57,255,20,0.1)]">
              <div className="text-center text-[#888]">
                <Navigation className="w-16 h-16 text-[#39ff14] mx-auto mb-4" />
                <h3 className="text-white text-xl font-semibold mb-2">GameCell - Curuai</h3>
                <p>Distrito de Curuai, Pará</p>
                <p className="mt-4 text-sm">
                  <span className="inline-flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Mapa interativo em breve
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0a0a0a] border-t border-[#333] py-12 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-2xl font-extrabold mb-4">
            Game<span className="text-[#39ff14]">Cell</span>
          </div>
          <p className="text-[#888] mb-8">
            Assistência Técnica Especializada em Smartphones
          </p>

          <div className="flex justify-center gap-6 mb-8">
            <a 
              href="#" 
              className="w-12 h-12 bg-[#1a1a1a] border border-[#333] rounded-full flex items-center justify-center text-white transition-all duration-300 hover:bg-[#39ff14] hover:text-[#0a0a0a] hover:border-[#39ff14] hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(57,255,20,0.4)]"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="w-12 h-12 bg-[#1a1a1a] border border-[#333] rounded-full flex items-center justify-center text-white transition-all duration-300 hover:bg-[#39ff14] hover:text-[#0a0a0a] hover:border-[#39ff14] hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(57,255,20,0.4)]"
              aria-label="Facebook"
            >
              <Facebook className="w-5 h-5" />
            </a>
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 bg-[#1a1a1a] border border-[#333] rounded-full flex items-center justify-center text-white transition-all duration-300 hover:bg-[#39ff14] hover:text-[#0a0a0a] hover:border-[#39ff14] hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(57,255,20,0.4)]"
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
          </div>

          <div className="border-t border-[#333] pt-8 text-[#888] text-sm">
            <p>&copy; 2024 GameCell. Todos os direitos reservados.</p>
            <p className="mt-2 text-xs">
              Distrito de Curuai - Pará | CNPJ: XX.XXX.XXX/0001-XX
            </p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Float Button */}
      <a 
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-float fixed bottom-8 right-8 w-16 h-16 bg-[#25d366] rounded-full flex items-center justify-center text-white text-3xl shadow-[0_0_20px_rgba(37,211,102,0.5)] z-50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(37,211,102,0.8)]"
        aria-label="WhatsApp"
      >
        <MessageCircle className="w-8 h-8" />
      </a>
    </div>
  );
}

export default App;
