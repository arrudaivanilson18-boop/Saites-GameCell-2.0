import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gamecell.app',
  appName: 'GameCell',
  webDir: 'dist'
};

export default config;
