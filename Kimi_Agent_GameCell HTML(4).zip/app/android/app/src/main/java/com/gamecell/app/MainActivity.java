package com.gamecell.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
