================================================================================
                    GAMECELL - SITE COMPLETO + PAINEL ADMIN
================================================================================

📁 ARQUIVOS INCLUÍDOS:
----------------------
✅ index.html           → Página principal do site
✅ admin-completo.html  → Painel administrativo COMPLETO
✅ admin.html           → Painel administrativo simples
✅ assets/              → Pasta com CSS e JavaScript
✅ README.txt           → Este arquivo (instruções)

================================================================================
🔐 PAINEL ADMINISTRATIVO - COMO USAR
================================================================================

1. Abra o arquivo "admin-completo.html" no seu navegador (Chrome, Safari, etc.)

2. Digite a senha: gamecell2024

3. No painel você pode:
   📊 Dashboard          → Ver visitas, vouchers, estatísticas
   📝 Textos do Site     → Editar frases, títulos, descrições
   🎥 Vídeos             → Adicionar links de vídeos do YouTube
   🖼️ Imagens            → Adicionar links de imagens
   💬 Depoimentos        → Adicionar depoimentos de clientes
   🎫 Vouchers           → Ver vouchers gerados, marcar como usado
   🔧 Serviços           → Adicionar/remover serviços
   💾 Exportar Site      → Gerar código atualizado

================================================================================
⚠️ IMPORTANTE - LEIA!
================================================================================

🔸 OS DADOS FICAM SALVOS NO SEU NAVEGADOR!
   - Se limpar o histórico/cookies, perde os dados do painel
   - Se trocar de celular/computador, o painel fica vazio
   - Use SEMPRE o mesmo dispositivo para administrar

🔸 PARA HOSPEDAR O SITE PERMANENTEMENTE:
   
   Opção 1: Vercel (GRÁTIS E RECOMENDADO)
   1. Acesse: https://vercel.com
   2. Crie conta com GitHub ou Google
   3. Clique em "Add New Project"
   4. Arraste esta pasta inteira
   5. Pronto! Seu link será: https://gamecell.vercel.app
   
   Opção 2: Netlify (GRÁTIS)
   1. Acesse: https://netlify.com
   2. Crie conta
   3. Arraste esta pasta
   4. Pronto! Seu link será: https://gamecell.netlify.app

================================================================================
📱 DADOS DO SITE
================================================================================

Nome:       GameCell
Segmento:   Assistência Técnica de Smartphones
Local:      Curuai, Pará
WhatsApp:   (93) 98420-1437

Funcionalidades:
✅ Site responsivo (funciona no celular e computador)
✅ Sistema de vouchers com 20% de desconto
✅ Contador de visitas
✅ Seção de depoimentos
✅ Integração com WhatsApp
✅ Painel administrativo completo

================================================================================
🎨 CORES DO SITE
================================================================================

Verde Neon:  #39ff14
Preto:       #0a0a0a
Cinza:       #1a1a1a
Branco:      #ffffff

================================================================================
💾 BACKUP CRIADO EM: 06/03/2025
================================================================================

Guarde este arquivo em um lugar seguro!

Dúvidas? Entre em contato pelo WhatsApp: (93) 98420-1437

================================================================================
