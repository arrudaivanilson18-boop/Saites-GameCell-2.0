# 🚀 COMO PUBLICAR O SITE GAMECELL NO VERCEL

## Passo 1: Acesse o Vercel
1. Vá para: https://vercel.com/dashboard
2. Faça login com sua conta

## Passo 2: Criar Novo Projeto
1. Clique no botão **"Add New..."** (canto superior direito)
2. Clique em **"Project"**

## Passo 3: Importar Projeto
Você tem duas opções:

### OPÇÃO A: Usar GitHub (Recomendado)
1. Clique em **"Import Git Repository"**
2. Conecte sua conta GitHub
3. Escolha o repositório do GameCell
4. Clique em **"Import"**
5. Clique em **"Deploy"**

### OPÇÃO B: Upload Direto (Sem GitHub)
1. Na tela de importação, procure por **"Upload"** ou **"Drag and drop"**
2. Arraste esta pasta inteira (gamecell-vercel) para a área indicada
3. Aguarde o upload
4. Clique em **"Deploy"**

## Passo 4: Aguardar Deploy
- O Vercel vai processar (leva 1-2 minutos)
- Quando terminar, aparece **"Congratulations!"**
- Clique em **"Go to Dashboard"** ou **"Visit"**

## Passo 5: Seu Site está no ar! 🎉
O link vai ser algo como:
```
https://gamecell.vercel.app
```

## Passo 6: Configurar Domínio (Opcional)
Se quiser um domínio personalizado:
1. No dashboard do projeto, clique em **"Settings"**
2. Clique em **"Domains"**
3. Adicione seu domínio (ex: gamecell.com.br)

---

## 📁 Arquivos do Projeto

- `index.html` - Página principal
- `admin-completo.html` - Painel administrativo
- `admin.html` - Painel simples
- `assets/` - CSS e JavaScript
- `vercel.json` - Configuração do Vercel

---

## 🔐 Painel Administrativo

Acesse: `https://seusite.vercel.app/admin-completo.html`

Senha: `gamecell2024`

---

## ⚠️ IMPORTANTE

O painel admin salva dados no navegador (localStorage). 
Para dados persistentes na nuvem, é necessário configurar um banco de dados (Firebase, etc).

---

Dúvidas? Entre em contato pelo WhatsApp: (93) 98420-1437
